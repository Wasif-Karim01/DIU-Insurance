<?php
DEFINE('DBHost','localhost');
DEFINE('DBUser', 'root');
DEFINE('DBPass','');
DEFINE('DBName','DIU-Insurance');
DEFINE('DBCharset','utf8mb4');
DEFINE('DBCollation', 'utf8_general_ci');
DEFINE('DBPrefix', '');
?>
