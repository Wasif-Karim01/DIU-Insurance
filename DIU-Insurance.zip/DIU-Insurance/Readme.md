1. Download DIU-Insurance as zip file then extract or clone it
2. Create a Database named diu-insurance through XAMPP and PHPMyAdmin in browser
3. Import Database.sql located inside DIU-Insurance->MySQL floder
4. To run the project paste the link in browser: http://localhost/DIU-Insurance/Script/
